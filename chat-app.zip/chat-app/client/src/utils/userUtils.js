export const statusColors = {
  online: 'bg-green-500',
  offline: 'bg-gray-500',
};

