import React from 'react';

const StoriesList = () => {
  return (
    <div className="p-4">
      <h2>Stories</h2>
    </div>
  );
};

export default StoriesList;
