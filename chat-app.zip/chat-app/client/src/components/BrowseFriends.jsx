import React from 'react';


const BrowseFriends = () => {

  return (
    <div className="p-4">

    </div>
  );
};

export default BrowseFriends;
