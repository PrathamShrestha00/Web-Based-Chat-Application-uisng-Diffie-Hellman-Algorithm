<<<<<<< HEAD
# Chatapp

Chatapp is minimal version of a chat application with feature like authentication,user listing,
proper user validation using jwt and real time chat using socket.io


## Screenshot
![screenshots](https://github.com/aayush2561/chat-app/blob/main/client/Preview.png)

## Features
- User Authentication:Signup with profile image using multer and proper validation and login with remember me section and jwt token.

- User listing : User can see the list of al the user for chatting with them.

- Protected Route: Routes are protected so only logged in users can access .

- Real time chat and user online and offline status :Using socket.io i have implemented proper real time communication.

  
## Technology Used

- React - frontend 
- Node and express -Backend
- Mongodb - Database

## Build Frontend

````
npm install
````
````
npm run dev
````

    
## Build backend
````
npm install
````
````
npm start
````
## Link
 https://chat-app-pink-phi.vercel.app/
=======
# Web-Based-Chat-Application-uisng-Diffie-Hellman-Algorithm
This is a real-time chat application built with React, Node.js, Express, and MySQL. It features user authentication, message sending, and encryption using the Diffie-Hellman algorithm for secure key exchange between users. The application ensures that messages are exchanged securely by generating shared secrets for each communication session.

Key Features:
User Authentication: Users can register and log in to the chat application.
Real-Time Messaging: Chat messages are sent and received in real-time using Socket.IO.
Diffie-Hellman Key Exchange: Ensures secure communication by performing a Diffie-Hellman key exchange between two users, providing a shared secret for encrypting messages.
MongoDB Database: User credentials, messages, and chat data are stored in a MongoDB database for persistence.
Secure Communication: Messages are encrypted using the shared secret generated via Diffie-Hellman, ensuring privacy and security.

Technologies Used:
Frontend: React.js, Vite
Backend: Node.js, Express
Database: MongoDB
Real-Time Communication: Socket.IO
Encryption: Diffie-Hellman Key Exchange Algorithm

Future Enhancements:
Adding support for group chats.
Implementing chat history retrieval and message persistence.
Improving the user interface and UX.
>>>>>>> f16904485cfa893c6d937abfda95436a35363aca
