const crypto = require('crypto');
const dotenv = require('dotenv');
 
dotenv.config();
 
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY;  
const IV_LENGTH = 16;  
 
function encryptMessage(message) {
    const iv = crypto.randomBytes(IV_LENGTH); 
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY, 'hex'), iv);
    let encryptedMessage = cipher.update(message, 'utf8', 'hex');
    encryptedMessage += cipher.final('hex');
    return { encryptedMessage, iv: iv.toString('hex') };
}
 
function decryptMessage(encryptedMessage, iv) {
    const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY, 'hex'), Buffer.from(iv, 'hex'));
    let decryptedMessage = decipher.update(encryptedMessage, 'hex', 'utf8');
    decryptedMessage += decipher.final('utf8');
    return decryptedMessage;
}
 
module.exports = { encryptMessage, decryptMessage };
 